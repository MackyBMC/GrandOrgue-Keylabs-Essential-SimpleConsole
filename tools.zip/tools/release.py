"""Release helper: bump version.py, date the changelog, commit, push, tag.

Usage:  python tools/release.py [VERSION]      (prompts when VERSION is missing)
VERSION is X.Y.Z or X.Y.Z-N with optional letters: 2.0.9, 2.0.9-1, 2.0.9-1a.

CHANGELOG
2026-11-21  Accepts X.Y.Z-N[letters]; renames "## Unreleased" in CHANGELOG.md to the version heading.
"""
import datetime
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
PATTERN = re.compile(r"^\d+\.\d+\.\d+(-\d+[a-z]*)?$")


def git(*args):
    subprocess.run(["git", *args], cwd=ROOT, check=True)


def main():
    version = (sys.argv[1] if len(sys.argv) > 1 else input("Version (2.0.9, 2.0.9-1, 2.0.9-1a): ")).strip().lstrip("vV")
    if not PATTERN.match(version):
        sys.exit(f"'{version}' is not X.Y.Z or X.Y.Z-N[letters]")
    today = datetime.date.today().isoformat()
    path = ROOT / "version.py"
    text = path.read_text(encoding="utf-8")
    text, count = re.subn(r'^APP_VERSION = "[^"]*"', f'APP_VERSION = "{version}"', text, count=1, flags=re.MULTILINE)
    if not count:
        sys.exit("APP_VERSION line not found in version.py")
    text = text.replace("CHANGELOG\n", f"CHANGELOG\n{today}  Prepare release v{version}.\n", 1)
    path.write_text(text, encoding="utf-8", newline="\n")
    log = ROOT / "CHANGELOG.md"
    body = log.read_text(encoding="utf-8")
    heading = f"## {version} ({today})"
    if "## Unreleased" in body:
        body = body.replace("## Unreleased", heading, 1)
    elif f"## {version}" not in body:
        body = body.replace("\n## ", f"\n{heading}\n- (add the changes)\n\n## ", 1)
    log.write_text(body, encoding="utf-8", newline="\n")
    if input(f"Commit, push and tag v{version}? [y/N] ").strip().lower() != "y":
        sys.exit("Stopped; version.py and CHANGELOG.md are changed but nothing is committed.")
    git("add", "-A")
    git("commit", "-m", f"Release v{version}")
    git("push")
    git("tag", f"v{version}")
    git("push", "origin", f"v{version}")


if __name__ == "__main__":
    main()
